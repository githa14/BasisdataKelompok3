<?php
session_start();
if ($_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_transaksi = $_POST['id_transaksi'];

    // Ambil detail transaksi
    $result = $koneksi->query("SELECT * FROM detail_transaksi WHERE id_transaksi = '$id_transaksi'");
    while ($row = $result->fetch_assoc()) {
        $id_barang = $row['id_barang'];
        $jumlah = $row['jumlah'];
        
        // Kembalikan stok barang
        $koneksi->query("UPDATE barang SET jumlah_barang = jumlah_barang + $jumlah WHERE id_barang = '$id_barang'");
    }

    // Update status transaksi
    $koneksi->query("UPDATE transaksi SET status = 'Dikembalikan' WHERE id_transaksi = '$id_transaksi'");

    echo "Barang berhasil dikembalikan!";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Pengembalian Barang</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <h2>Form Pengembalian Barang</h2>
    <form method="POST">
        <label>Pilih Transaksi:</label>
        <select name="id_transaksi">
            <?php
            $result = $koneksi->query("SELECT transaksi.id_transaksi, siswa.nama_siswa FROM transaksi 
                                       JOIN siswa ON transaksi.id_siswa = siswa.nis 
                                       WHERE transaksi.status = 'Dipinjam'");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id_transaksi']}'>ID: {$row['id_transaksi']} - {$row['nama_siswa']}</option>";
            }
            ?>
        </select><br>
        <input type="submit" value="Kembalikan">
    </form>
</body>
</html>