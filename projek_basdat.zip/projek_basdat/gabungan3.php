<?php
session_start();

// Pastikan koneksi database tersedia
include 'koneksi3.php';
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Pastikan hanya administrator yang bisa mengakses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gabungan Data Inventaris</title>
    <link rel="stylesheet" href="style_gabungan.css">
    <script>
        function searchTable(inputId, tableId) {
            let input = document.getElementById(inputId).value.toLowerCase();
            let table = document.getElementById(tableId);
            let rows = table.getElementsByTagName("tr");
            for (let i = 1; i < rows.length; i++) {
                let cells = rows[i].getElementsByTagName("td");
                let found = false;
                for (let cell of cells) {
                    if (cell.innerText.toLowerCase().includes(input)) {
                        found = true;
                        break;
                    }
                }
                rows[i].style.display = found ? "" : "none";
            }
        }
    </script>
</head>
<body>
<nav class="navbar">    
    <div class="navbar-container">
        <div class="navbar-brand">
            <h2>Inventaris Sekolah</h2>
        </div>
        <ul class="navbar-menu">
            <li><a href="index.php">Kembali</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <h2>Data Barang</h2>
    <input type="text" id="searchBarang" onkeyup="searchTable('searchBarang', 'tableBarang')" placeholder="Cari Barang...">
    <table id="tableBarang" border="1">
        <tr>
            <th>Nama Barang</th>
            <th>Tipe</th>
            <th>Jumlah</th>
            <th>Lokasi Penyimpanan</th>
            <th>Aksi</th>
        </tr>
        <?php
        $query = "SELECT barang.id_barang, barang.nama_barang, barang.tipe_barang, barang.jumlah_barang, ruang.nama_ruang 
                  FROM barang 
                  LEFT JOIN ruang ON barang.id_ruang = ruang.id_ruang";

        $result = $conn->query($query);

        if (!$result) {
            die("Error pada query: " . mysqli_error($conn));
        }

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $lokasi = !empty($row['nama_ruang']) ? $row['nama_ruang'] : "Tidak diketahui";

                echo "<tr>
                        <td>{$row['nama_barang']}</td>
                        <td>{$row['tipe_barang']}</td>
                        <td>{$row['jumlah_barang']}</td>
                        <td>{$lokasi}</td>
                        <td>
                            <a href='edit_barang.php?id={$row['id_barang']}'>Edit</a> |
                            <a href='hapus_barang.php?id={$row['id_barang']}' onclick='return confirm(\"Yakin ingin menghapus?\")'>Hapus</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Tidak ada data barang.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
