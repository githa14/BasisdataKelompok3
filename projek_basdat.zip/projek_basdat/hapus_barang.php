<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi3.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID tidak valid.");
}

$id = intval($_GET['id']);

$stmt = $conn->prepare("DELETE FROM barang WHERE id_barang = ?");
if ($stmt) {
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "<script>alert('Data berhasil dihapus!'); window.location.href='gabungan3.php';</script>";
    } else {
        echo "Error deleting record: " . $stmt->error;
    }
} else {
    echo "Query Error: " . $conn->error;
}
?>
