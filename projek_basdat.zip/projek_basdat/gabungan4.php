<?php
session_start();

include 'koneksi3.php';
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gabungan Data Inventaris</title>
    <link rel="stylesheet" href="style_gabungan.css">
    <script>
        function searchTable(inputId, tableId) {
            let input = document.getElementById(inputId).value.toLowerCase();
            let table = document.getElementById(tableId);
            let rows = table.getElementsByTagName("tr");
            for (let i = 1; i < rows.length; i++) {
                let cells = rows[i].getElementsByTagName("td");
                let found = false;
                for (let cell of cells) {
                    if (cell.innerText.toLowerCase().includes(input)) {
                        found = true;
                        break;
                    }
                }
                rows[i].style.display = found ? "" : "none";
            }
        }
    </script>
</head>
<body>
<nav class="navbar">    
    <div class="navbar-container">
        <div class="navbar-brand">
            <h2>Inventaris Sekolah</h2>
        </div>
        <ul class="navbar-menu">
            <li><a href="index.php">Kembali</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <h2>Data Peminjaman</h2>
    <input type="text" id="searchPeminjaman" onkeyup="searchTable('searchPeminjaman', 'tablePeminjaman')" placeholder="Cari Peminjaman...">
    <table id="tablePeminjaman" border="1">
        <tr>
            <th>Nama Siswa</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Barang</th>
            <th>Jumlah</th>
            <th>Aksi</th>
        </tr>
        <?php
        $query = "SELECT transaksi.id_transaksi, siswa.nama_siswa, transaksi.tanggal_pinjam, transaksi.tanggal_kembali, barang.nama_barang, detail_transaksi.jumlah
                  FROM transaksi 
                  JOIN siswa ON transaksi.id_siswa = siswa.id_siswa 
                  JOIN detail_transaksi ON transaksi.id_transaksi = detail_transaksi.id_transaksi 
                  JOIN barang ON detail_transaksi.id_barang = barang.id_barang";

        $result = $conn->query($query);
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['nama_siswa']}</td>
                        <td>{$row['tanggal_pinjam']}</td>
                        <td>{$row['tanggal_kembali']}</td>
                        <td>{$row['nama_barang']}</td>
                        <td>{$row['jumlah']}</td>
                        <td>
                            <a href='edit_peminjaman.php?id={$row['id_transaksi']}'>Edit</a> |
                            <a href='hapus_peminjaman.php?id={$row['id_transaksi']}' onclick='return confirm(\"Yakin ingin menghapus?\")'>Hapus</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>Tidak ada data peminjaman.</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
