<?php
session_start();
if ($_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

$sql = "SELECT transaksi.id_transaksi, siswa.nama_siswa, transaksi.tanggal_pinjam, transaksi.tanggal_kembali, transaksi.status 
        FROM transaksi 
        JOIN siswa ON transaksi.id_siswa = siswa.nis";
$result = $koneksi->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Riwayat Peminjaman</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <h2>Riwayat Peminjaman</h2>
    <table border="1">
        <tr>
            <th>ID Transaksi</th>
            <th>Nama Siswa</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Status</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id_transaksi']; ?></td>
            <td><?php echo $row['nama_siswa']; ?></td>
            <td><?php echo $row['tanggal_pinjam']; ?></td>
            <td><?php echo $row['tanggal_kembali']; ?></td>
            <td><?php echo $row['status']; ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>