<?php
include 'koneksi3.php';

if (isset($_GET['id'])) {
    $id_ruang = $_GET['id'];
    $query = $conn->query("SELECT * FROM ruang WHERE id_ruang = '$id_ruang'");

    if (!$query) {
        die(json_encode(['error' => 'Query gagal: ' . $conn->error]));
    }

    if ($query->num_rows > 0) {
        $data = $query->fetch_assoc();

        $barangQuery = $conn->query("SELECT nama_barang FROM barang WHERE id_ruang = '$id_ruang'");
        $barangList = "";
        while ($barang = $barangQuery->fetch_assoc()) {
            $barangList .= "<li>{$barang['nama_barang']}</li>";
        }

        echo json_encode([
            'nama_ruang' => $data['nama_ruang'],
            'lokasi' => $data['lokasi'],
            'kapasitas' => $data['kapasitas'],
            'barang' => $barangList
        ]);
    } else {
        echo json_encode(['error' => 'Data tidak ditemukan']);
    }
} else {
    echo json_encode(['error' => 'ID tidak diberikan']);
}
?>
