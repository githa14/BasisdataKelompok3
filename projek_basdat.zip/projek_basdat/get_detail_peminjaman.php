<?php
include 'koneksi3.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT transaksi.id_transaksi, siswa.nama_siswa, transaksi.tanggal_pinjam, transaksi.tanggal_kembali, barang.nama_barang, detail_transaksi.jumlah, transaksi.status_pinjam
              FROM transaksi
              JOIN siswa ON transaksi.id_siswa = siswa.id_siswa
              JOIN detail_transaksi ON transaksi.id_transaksi = detail_transaksi.id_transaksi
              JOIN barang ON detail_transaksi.id_barang = barang.id_barang
              WHERE transaksi.id_transaksi = $id";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo json_encode(['error' => 'Data tidak ditemukan']);
    }
}
?>
