<?php
session_start();
require 'koneksi3.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['action'])) {
    if ($_GET['action'] == "get") {
        $result = $conn->query("SELECT * FROM barang");
        $barang = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($barang);
        exit;
    }

    if ($_GET['action'] == "delete" && isset($_GET['id'])) {
        $id = (int)$_GET['id'];
        $stmt = $conn->prepare("DELETE FROM barang WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        echo json_encode(["status" => "success"]);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $namaBarang = trim($_POST['namaBarang']);
    $tipeBarang = trim($_POST['tipeBarang']);
    $jumlahBarang = (int)$_POST['jumlahBarang'];

    if ($namaBarang === '' || $tipeBarang === '' || $jumlahBarang <= 0) {
        echo json_encode(["status" => "error", "message" => "Semua kolom wajib diisi"]);
        exit;
    }

    if (isset($_POST['editId']) && $_POST['editId'] !== '') {
        $id = (int)$_POST['editId'];
        $stmt = $conn->prepare("UPDATE barang SET nama_barang=?, tipe_barang=?, jumlah_barang=? WHERE id=?");
        $stmt->bind_param("ssii", $namaBarang, $tipeBarang, $jumlahBarang, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO barang (nama_barang, tipe_barang, jumlah_barang) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $namaBarang, $tipeBarang, $jumlahBarang);
    }

    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Gagal menyimpan barang"]);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Data Barang</title>
    <link rel="stylesheet" href="style4.css">
    <script defer src="script.js"></script>
</head>
<body>
    <nav class="navbar">    
        <div class="navbar-container">
            <div class="navbar-brand">
                <h2>Inventaris Sekolah</h2>
            </div>
            <ul class="navbar-menu">
                <li><a href="index2.php">Kembali</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h2>Manajemen Data Barang</h2>
        <form id="barangForm">
            <input type="hidden" id="editId" name="editId">
            <input type="text" id="namaBarang" name="namaBarang" placeholder="Nama Barang" required>
            <input type="text" id="tipeBarang" name="tipeBarang" placeholder="Tipe Barang" required>
            <input type="number" id="jumlahBarang" name="jumlahBarang" placeholder="Jumlah Barang" required>
            <button type="submit">Tambah Barang</button>
        </form>
        
    </div>
</body>
</html>
