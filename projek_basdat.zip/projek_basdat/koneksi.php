<?php
$host = "localhost";
$user = "root";  // Sesuaikan dengan user database Anda
$pass = "";      // Sesuaikan dengan password database Anda
$dbname = "projek_basdat"; // Sesuaikan dengan nama database Anda

$koneksi = new mysqli($host, $user, $pass, $dbname);

// Cek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}
?>