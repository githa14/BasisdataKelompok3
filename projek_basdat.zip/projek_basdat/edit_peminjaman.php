<?php
session_start();
if ($_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

if (!isset($_GET['id'])) {
    die("ID Transaksi tidak ditemukan!");
}

$id_transaksi = $_GET['id'];

$query = "SELECT transaksi.*, detail_transaksi.id_barang, detail_transaksi.jumlah 
          FROM transaksi 
          JOIN detail_transaksi ON transaksi.id_transaksi = detail_transaksi.id_transaksi
          WHERE transaksi.id_transaksi = '$id_transaksi'";
$result = $koneksi->query($query);
$transaksi = $result->fetch_assoc();

if (!$transaksi) {
    die("Data tidak ditemukan!");
}

$id_siswa = $transaksi['id_siswa'];
$tanggal_pinjam = $transaksi['tanggal_pinjam'];
$tanggal_kembali = $transaksi['tanggal_kembali'];
$id_barang = $transaksi['id_barang'];
$jumlah_sebelumnya = $transaksi['jumlah']; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_siswa = $_POST['id_siswa'];
    $tanggal_pinjam = $_POST['tanggal_pinjam'];
    $tanggal_kembali = $_POST['tanggal_kembali'];
    $id_barang_baru = $_POST['id_barang'];
    $jumlah_baru = $_POST['jumlah'];

    $koneksi->begin_transaction();

    try {
        $koneksi->query("UPDATE barang SET jumlah_barang = jumlah_barang + $jumlah_sebelumnya WHERE id_barang = '$id_barang'");

        $sql_transaksi = "UPDATE transaksi 
                          SET id_siswa='$id_siswa', tanggal_pinjam='$tanggal_pinjam', tanggal_kembali='$tanggal_kembali' 
                          WHERE id_transaksi='$id_transaksi'";
        $koneksi->query($sql_transaksi);

        $sql_detail = "UPDATE detail_transaksi 
                       SET id_barang='$id_barang_baru', jumlah='$jumlah_baru' 
                       WHERE id_transaksi='$id_transaksi'";
        $koneksi->query($sql_detail);

        $koneksi->query("UPDATE barang SET jumlah_barang = jumlah_barang - $jumlah_baru WHERE id_barang = '$id_barang_baru'");

        $koneksi->commit(); 

        $id_barang = $id_barang_baru;
        $jumlah_sebelumnya = $jumlah_baru;

        echo "<p style='color: green;'>Data berhasil diperbarui!</p>";
        header("Location: gabungan4.php");
        exit();
        
    } catch (Exception $e) {
        echo "<p style='color:red;'>Terjadi kesalahan: " . $e->getMessage() . "</p>";
        $koneksi->rollback(); 
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Edit Peminjaman</title>
    <link rel="stylesheet" href="style_edit2.css">
</head>
<body>
    <form method="POST">
        <label>Nama Siswa:</label>
        <select name="id_siswa" required>
            <?php
            $siswa_result = $koneksi->query("SELECT * FROM siswa");
            while ($row = $siswa_result->fetch_assoc()) {
                $selected = ($row['id_siswa'] == $id_siswa) ? "selected" : "";
                echo "<option value='{$row['id_siswa']}' $selected>{$row['nama_siswa']}</option>";
            }
            ?>
        </select><br>

        <label>Tanggal Pinjam:</label>
        <input type="date" name="tanggal_pinjam" value="<?php echo $tanggal_pinjam; ?>" required><br>

        <label>Tanggal Kembali:</label>
        <input type="date" name="tanggal_kembali" value="<?php echo $tanggal_kembali; ?>" required><br>

        <label>Barang:</label>
        <select name="id_barang" required>
            <?php
            $barang_result = $koneksi->query("SELECT * FROM barang");
            while ($row = $barang_result->fetch_assoc()) {
                $selected = ($row['id_barang'] == $id_barang) ? "selected" : "";
                echo "<option value='{$row['id_barang']}' $selected>{$row['nama_barang']} - Stok: {$row['jumlah_barang']}</option>";
            }
            ?>
        </select><br>

        <label>Jumlah:</label>
        <input type="number" name="jumlah" min="1" max="100" value="<?php echo $jumlah_sebelumnya; ?>" required><br>

        <input type="submit" value="Update Peminjaman">
    </form>
</body>
</html>
