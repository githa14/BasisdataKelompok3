<?php
$host = "localhost";
$user = "root";  // Sesuai konfigurasi XAMPP
$pass = "";      // Kosong jika default XAMPP
$dbname = "projek_basdat";

$conn = new mysqli($host, $user, $pass, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

?>
