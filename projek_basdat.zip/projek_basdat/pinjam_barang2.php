<?php
session_start();
if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_siswa = $_POST['id_siswa'] ?? null;
    $tanggal_pinjam = $_POST['tanggal_pinjam'] ?? null;
    $tanggal_kembali = $_POST['tanggal_kembali'] ?? null;
    $id_barang = $_POST['barang_id'] ?? null;
    $jumlah = $_POST['jumlah'] ?? null;

    if ($id_siswa && $tanggal_pinjam && $tanggal_kembali && $id_barang && $jumlah) {
        $sql_transaksi = "INSERT INTO transaksi (id_siswa, tanggal_pinjam, tanggal_kembali) VALUES ('$id_siswa', '$tanggal_pinjam', '$tanggal_kembali')";
        if ($koneksi->query($sql_transaksi)) {
            $id_transaksi = $koneksi->insert_id;
            $sql_detail = "INSERT INTO detail_transaksi (id_transaksi, id_barang, jumlah) VALUES ('$id_transaksi', '$id_barang', '$jumlah')";
            $koneksi->query($sql_detail);
            $koneksi->query("UPDATE barang SET jumlah_barang = jumlah_barang - $jumlah WHERE id_barang = '$id_barang'");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Peminjaman Barang</title>
    <link rel="stylesheet" href="style2.css">
    <style>
        .btn { padding: 5px 10px; border: none; cursor: pointer; border-radius: 5px; display: inline-block; text-align: center; }
        .btn-detail { background: blue; color: white; }
        .btn-edit { background: orange; color: white; }
        .btn-hapus { background: red; color: white; }
    </style>
    <script>
        function tampilkanDetail(siswa, tanggalPinjam, tanggalKembali, barang, jumlah, status) {
            alert(`Siswa: ${siswa}\nTanggal Pinjam: ${tanggalPinjam}\nTanggal Kembali: ${tanggalKembali}\nBarang: ${barang}\nJumlah: ${jumlah}\nStatus: ${status}`);
        }
    </script>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="navbar-container">
            <div class="navbar-brand">
                <h2>Inventaris Sekolah</h2>
            </div>
            <ul class="navbar-menu">
                <li><a href="index2.php">Kembali</a></li>
            </ul>
        </div>
    </nav>
    <form method="POST">
        <label>Nama Siswa:</label>
        <select name="id_siswa" required>
            <option value="">-- Pilih Siswa --</option>
            <?php
            $result = $koneksi->query("SELECT * FROM siswa");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id_siswa']}'>{$row['nama_siswa']}</option>";
            }
            ?>
        </select><br>

        <label>Tanggal Pinjam:</label>
        <input type="date" name="tanggal_pinjam" required><br>
        <label>Tanggal Kembali:</label>
        <input type="date" name="tanggal_kembali" required><br>

        <label>Barang:</label>
        <select name="barang_id" required>
            <option value="">-- Pilih Barang --</option>
            <?php
            $result = $koneksi->query("SELECT * FROM barang WHERE jumlah_barang > 0");
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id_barang']}'>{$row['nama_barang']} (Stok: {$row['jumlah_barang']})</option>";
            }
            ?>
        </select><br>

        <label>Jumlah:</label>
        <input type="number" name="jumlah" min="1" max="100" value="1" required><br>

        <input type="submit" value="Pinjam">
    </form>

</body>
</html>
