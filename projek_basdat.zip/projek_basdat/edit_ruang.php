<?php
session_start();
if ($_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

$row = [];

if (isset($_GET['id'])) {
    $id_ruang = intval($_GET['id']);
    $query = "SELECT * FROM ruang WHERE id_ruang=$id_ruang";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        die("Query gagal: " . mysqli_error($koneksi));
    }

    $row = mysqli_fetch_assoc($result);
    if (!$row) {
        die("Data tidak ditemukan.");
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_ruang = intval($_POST['id_ruang']);
    $nama_ruang = mysqli_real_escape_string($koneksi, $_POST['nama_ruang']);
    $lokasi = mysqli_real_escape_string($koneksi, $_POST['lokasi']);
    $kapasitas = intval($_POST['kapasitas']);

    $query = "UPDATE ruang 
              SET nama_ruang='$nama_ruang', lokasi='$lokasi', kapasitas='$kapasitas' 
              WHERE id_ruang=$id_ruang";

    if (mysqli_query($koneksi, $query)) {
        echo "Data berhasil diperbarui!";
        header("Location: gabungan5.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Ruangan</title>
    <link rel="stylesheet" href="style_edit.css">
</head>
<body>

<form method="post">
    <input type="hidden" name="id_ruang" value="<?= isset($row['id_ruang']) ? $row['id_ruang'] : '' ?>">
    
    <label>Nama Ruang:</label>
    <input type="text" name="nama_ruang" value="<?= isset($row['nama_ruang']) ? $row['nama_ruang'] : '' ?>" required><br>

    <label>Lokasi:</label>
    <input type="text" name="lokasi" value="<?= isset($row['lokasi']) ? $row['lokasi'] : '' ?>" required><br>

    <label>Kapasitas:</label>
    <input type="number" name="kapasitas" value="<?= isset($row['kapasitas']) ? $row['kapasitas'] : '' ?>" required><br>

    <button type="submit">Update</button>
</form>

</body>
</html>
