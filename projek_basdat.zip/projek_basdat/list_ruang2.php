<?php
session_start();
if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

// Proses penambahan ruang jika form dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_ruang = $_POST['nama_ruang'] ?? null;
    $lokasi = $_POST['lokasi'] ?? null;
    $kapasitas = $_POST['kapasitas'] ?? null;

    if ($nama_ruang && $lokasi && $kapasitas) {
        $sql_insert = "INSERT INTO ruang (nama_ruang, lokasi, kapasitas) 
                       VALUES ('$nama_ruang', '$lokasi', '$kapasitas')";

        if (mysqli_query($koneksi, $sql_insert)) {
            echo "<p style='color: green;'>Ruang berhasil ditambahkan!</p>";
            header("Refresh: 1"); // Refresh otomatis setelah berhasil
        } else {
            echo "<p style='color: red;'>Gagal menambahkan ruang: " . mysqli_error($koneksi) . "</p>";
        }
    } else {
        echo "<p style='color: red;'>Harap isi semua bidang formulir.</p>";
    }
}

// Ambil data dari tabel ruang untuk ditampilkan di daftar ruang
$query = "SELECT * FROM ruang";
$result = mysqli_query($koneksi, $query);

// Cek apakah query berhasil
if (!$result) {
    die("Query gagal: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Ruang</title>
    <link rel="stylesheet" href="style_list_ruang.css">
</head>
<body>

    <nav class="navbar">
        <div class="navbar-container">
            <div class="navbar-brand">
                <h2>Inventaris Sekolah</h2>
            </div>
            <ul class="navbar-menu">
                <li><a href="index2.php">Kembali</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <form method="POST">
            <label>Nama Ruang:</label>
            <input type="text" name="nama_ruang" required><br>

            <label>Lokasi:</label>
            <input type="text" name="lokasi" required><br>

            <label>Kapasitas:</label>
            <input type="number" name="kapasitas" min="1" required><br>

            <button type="submit">Tambah Ruang</button>
        </form>

    </div>
</body>
</html>
