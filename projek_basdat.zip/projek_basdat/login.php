<?php
include "koneksii.php";
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['role'])) {
        $username = $_POST['username'];
        $password = md5($_POST['password']);
        $role = $_POST['role'];

        $query = "SELECT * FROM user WHERE username='$username' AND password='$password' AND role='$role'";
        $result = mysqli_query($koneksi, $query);

        if (mysqli_num_rows($result) == 1) {
            $user = mysqli_fetch_assoc($result);
            $_SESSION['id_user'] = $user['UserID'];
            $_SESSION['nama'] = $user['NamaLengkap'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Redirect berdasarkan role yang dipilih
            if ($_SESSION['role'] === 'administrator') {
                echo "<script>alert('Login berhasil! Selamat datang, Administrator');</script>";
                echo "<script>window.location.href = 'index.php';</script>";
                exit;
            } elseif ($_SESSION['role'] === 'user') {
                echo "<script>alert('Login berhasil! Selamat datang, User');</script>";
                echo "<script>window.location.href = 'index2.php';</script>";
                exit;
            } else {
                echo "<script>alert('Role tidak dikenal!');</script>";
            }
        } else {
            echo "<script>alert('Username, Password, atau Role salah!');</script>";
        }
    } else {
        echo "<script>alert('Harap masukkan username, password, dan role!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <h2 class="text-center">Login</h2>
        <h2 class="text-center"></h2>
        <form action="login.php" method="POST" class="form-box">
            <div class="mb-3">
                <input type="text" class="form-control" name="username" placeholder="Username" required>
            </div>
            <div class="mb-3">
                <input type="password" class="form-control" name="password" placeholder="Password" required>
            </div>
            <div class="mb-3">
                <select name="role" class="form-control" required>
                    <option value="" disabled selected>Pilih Role</option>
                    <option value="administrator">Administrator</option>
                    <option value="administrator">User</option>
                </select>
            </div>
            <div>
                <input type="submit" value="Submit" class="btn btn-primary">
            </div>
        </form>
    </div>
</html>

