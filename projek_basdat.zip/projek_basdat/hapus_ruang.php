<?php
session_start();
if ($_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

if (isset($_GET['id'])) {
    $id_ruang = $_GET['id'];
    $query = "DELETE FROM ruang WHERE id_ruang=$id_ruang";
    
    if (mysqli_query($koneksi, $query)) {
        echo "Data berhasil dihapus!";
        header("Location: gabungan5.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>