document.addEventListener("DOMContentLoaded", () => {
    const barangForm = document.getElementById("barangForm");
    const barangList = document.getElementById("barangList");
    let editId = null;

    function loadBarang() {
        fetch("manajemen.php?action=get")
            .then(response => response.json())
            .then(data => {
                barangList.innerHTML = "";
                data.forEach(barang => {
                    let tr = document.createElement("tr");
                    tr.innerHTML = `
                        <td>${barang.nama_barang}</td>
                        <td>${barang.tipe_barang}</td>
                        <td>${barang.jumlah_barang}</td>
                        <td>
                            <button onclick="editBarang(${barang.id}, '${barang.nama_barang}', '${barang.tipe_barang}', ${barang.jumlah_barang})">Edit</button>
                            <button onclick="hapusBarang(${barang.id})">Hapus</button>
                        </td>
                    `;
                    barangList.appendChild(tr);
                });
            })
            .catch(error => console.error("Error loading data:", error));
    }

    barangForm.addEventListener("submit", function (event) {
        event.preventDefault();
        let formData = new FormData(barangForm);
        if (editId !== null) formData.append("editId", editId);

        fetch("manajemen.php", { method: "POST", body: formData })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    barangForm.reset();
                    editId = null;
                    loadBarang();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error("Error submitting data:", error));
    });

    window.editBarang = function (id, nama, tipe, jumlah) {
        document.getElementById("editId").value = id;
        document.getElementById("namaBarang").value = nama;
        document.getElementById("tipeBarang").value = tipe;
        document.getElementById("jumlahBarang").value = jumlah;
        editId = id;
    };

    window.hapusBarang = function (id) {
        if (confirm("Yakin ingin menghapus barang ini?")) {
            fetch(`manajemen.php?action=delete&id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        loadBarang();
                    } else {
                        alert("Gagal menghapus barang");
                    }
                })
                .catch(error => console.error("Error deleting data:", error));
        }
    };

    loadBarang();
});
