<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi3.php';

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID barang tidak valid.");
}

$id = intval($_GET['id']);

$result = $conn->query("SHOW COLUMNS FROM barang LIKE 'id_barang'");
if ($result->num_rows == 0) {
    die("Error: Kolom 'id_barang' tidak ditemukan di tabel barang.");
}

$stmt = $conn->prepare("SELECT * FROM barang WHERE id_barang = ?");
if (!$stmt) {
    die("Query Error: " . $conn->error);
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Data barang tidak ditemukan.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_barang = trim($_POST['nama_barang']);
    $jumlah_barang = intval($_POST['jumlah_barang']);

    if (empty($nama_barang) || $jumlah_barang <= 0) {
        echo "<script>alert('Harap isi semua data dengan benar!');</script>";
    } else {
        $stmt = $conn->prepare("UPDATE barang SET nama_barang=?, jumlah_barang=? WHERE id_barang=?");
        $stmt->bind_param("sii", $nama_barang, $jumlah_barang, $id);

        if ($stmt->execute()) {
            echo "<script>alert('Data berhasil diperbarui!'); window.location.href='gabungan3.php';</script>";
            exit();
        } else {
            echo "Error updating record: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Edit Barang</title>
    <link rel="stylesheet" href="style_edit.css">
</head>
<body>
    <form method="POST">
        <label>Nama Barang:</label>
        <input type="text" name="nama_barang" value="<?php echo htmlspecialchars($row['nama_barang']); ?>" required><br>

        <label>Jumlah:</label>
        <input type="number" name="jumlah_barang" value="<?php echo $row['jumlah_barang']; ?>" required><br>

        <button type="submit"><a href="gabungan3.php">Update</a></button>
    </form>
</body>
</html>
