<?php
session_start();
if ($_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="navbar-container">
            <div class="navbar-brand">
                <h2>Inventaris Sekolah</h2>
            </div>
            <ul class="navbar-menu">
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Main Content Area -->
    <div class="main-content">
        <!--<div class="content-header">
            <h2>Welcome</h2>
            <p>Here is your dashboard overview</p>
        </div>-->
        <br>
        <div class="feature-container">
            <h1> Beranda</h1>
            <a href="manajemen2.php" class="feature-box">📦 Manajemen Data Barang</a>
            <a href="pinjam_barang2.php" class="feature-box">📑 Peminjaman & Pengelolaan Barang</a>
            <a href="list_ruang2.php" class="feature-box">📌 Pendataan Ruang Penyimpanan</a>
            <a href="gabungan2.php" class="feature-box">Data-data dari 3 Fitur</a>
        </div>
    </div>

</body>
</html>
