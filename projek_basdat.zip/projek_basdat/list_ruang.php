<?php
session_start();
if ($_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_ruang = $_POST['nama_ruang'] ?? null;
    $lokasi = $_POST['lokasi'] ?? null;
    $kapasitas = $_POST['kapasitas'] ?? null;

    if ($nama_ruang && $lokasi && $kapasitas) {
        $sql_insert = "INSERT INTO ruang (nama_ruang, lokasi, kapasitas) 
                       VALUES ('$nama_ruang', '$lokasi', '$kapasitas')";

        if (mysqli_query($koneksi, $sql_insert)) {
            echo "<p style='color: green;'>Ruang berhasil ditambahkan!</p>";
            header("Refresh: 1"); 
        } else {
            echo "<p style='color: red;'>Gagal menambahkan ruang: " . mysqli_error($koneksi) . "</p>";
        }
    } else {
        echo "<p style='color: red;'>Harap isi semua bidang formulir.</p>";
    }
}

$query = "SELECT * FROM ruang";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die("Query gagal: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Ruang</title>
    <link rel="stylesheet" href="style_list_ruang.css">
    <style>
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            background-color: #3498db;
            color: white;
            cursor: pointer;
            margin-right: 10px;
            text-decoration: none;
            display: inline-block;
        }

        .btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="navbar-container">
            <div class="navbar-brand">
                <h2>Inventaris Sekolah</h2>
            </div>
            <ul class="navbar-menu">
                <li><a href="index.php">Kembali</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <form method="POST">
            <label>Nama Ruang:</label>
            <input type="text" name="nama_ruang" required><br>

            <label>Lokasi:</label>
            <input type="text" name="lokasi" required><br>

            <label>Kapasitas:</label>
            <input type="number" name="kapasitas" min="1" required><br>

            <button type="submit" class="btn">Tambah Ruang</button>
            <a href="gabungan5.php" class="btn">Tampilan Data</a>
        </form>
    </div>

</body>
</html>
