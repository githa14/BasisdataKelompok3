<?php
session_start();
if ($_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

if (isset($_GET['id'])) {
    $id_transaksi = $_GET['id'];

    $koneksi->query("DELETE FROM detail_transaksi WHERE id_transaksi = '$id_transaksi'");
    
    $query = "DELETE FROM transaksi WHERE id_transaksi = '$id_transaksi'";
    if ($koneksi->query($query)) {
        echo "<script>alert('Peminjaman berhasil dihapus.'); window.location='gabungan4.php';</script>";
    } else {
        echo "<p style='color: red;'>Gagal menghapus data!</p>";
    }
}
?>
