<?php
session_start();
include 'koneksi3.php';
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'administrator') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gabungan Data Inventaris</title>
    <link rel="stylesheet" href="style_gabungan2.css">
    <script>
        function showDetails(id_ruang) {
            fetch(`get_ruang_detail.php?id=${id_ruang}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('detailNamaRuang').innerText = data.nama_ruang;
                    document.getElementById('detailLokasi').innerText = data.lokasi;
                    document.getElementById('detailKapasitas').innerText = data.kapasitas;
                    document.getElementById('detailBarang').innerHTML = data.barang;
                    
                    document.getElementById('detailAksi').innerHTML = `
                        <a href="edit_ruang.php?id=${id_ruang}" class="btn-edit">Edit</a>
                        <a href="hapus_ruang.php?id=${id_ruang}" class="btn-hapus" onclick="return confirm('Yakin ingin menghapus ruang ini?')">Hapus</a>
                    `;
                })
                .catch(error => console.error('Error:', error));
        }
    </script>
    <style>
        .btn-edit, .btn-hapus {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            color: white;
            font-weight: 600;
            margin-top: 10px;
            margin-right: 10px;
            transition: background 0.3s;
        }

        .btn-edit {
            background-color: #28a745;
        }

        .btn-edit:hover {
            background-color: #218838;
        }

        .btn-hapus {
            background-color: #dc3545;
        }

        .btn-hapus:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <div class="navbar-container">
        <div class="navbar-brand">
            <h2>Inventaris Sekolah</h2>
        </div>
        <ul class="navbar-menu">
            <li><a href="index.php">Kembali</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <h2>Data Ruang Penyimpanan</h2>
    <select id="ruangSelect" onchange="showDetails(this.value)">
        <option value="">Pilih Ruang...</option>
        <?php
        $result = $conn->query("SELECT * FROM ruang");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['id_ruang']}'>{$row['nama_ruang']}</option>";
        }
        ?>
    </select>

    <h3>Detail Ruangan</h3>
    <p><strong>Nama Ruang:</strong> <span id="detailNamaRuang"></span></p>
    <p><strong>Lokasi:</strong> <span id="detailLokasi"></span></p>
    <p><strong>Kapasitas:</strong> <span id="detailKapasitas"></span></p>
    <h4>Barang di Ruangan:</h4>
    <ul id="detailBarang"></ul>

    <div id="detailAksi"></div>
</div>
</body>
</html>
